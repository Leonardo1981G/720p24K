#!/usr/bin/env python3
"""Standalone local video upscaler (Windows). Start it with run.bat; the UI opens at http://127.0.0.1:8765

Pipeline: decode -> centre-crop to 16:9 (or 9:16) -> optional Waifu2x / Real-ESRGAN pre-upscale
          -> optional NVIDIA DLSS 5 neural rendering (native worker, no ComfyUI) -> one final encode + original audio.
Frames are streamed in small chunks, so disk use stays small and the video is encoded exactly once."""
import contextlib, json, math, os, re, shutil, subprocess, sys, threading, time, traceback, uuid, webbrowser
from collections import deque
from fractions import Fraction
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from itertools import islice
from datetime import datetime
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

APP = Path(__file__).resolve().parent
sys.path.insert(0, str(APP))
try:
    import numpy as np
    import cv2
    import av
    from dlss5 import media, paths as dpaths
    from dlss5.imaging import fit_frame
    from dlss5.motion import TemporalGuide
    from dlss5.session import DlssSession
    from dlss5.settings import DlssOptions, resolve_output_size, resolve_upscaling
except ImportError as exc:
    print("Missing component: %s\nRun setup.bat first (it installs everything into this folder)." % exc)
    input("Press Enter to close...")
    sys.exit(1)

TOOLS, WORK = APP / "tools", APP / "work"
PORT = 8765
EXE = ".exe" if os.name == "nt" else ""
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

ENGINES = {
    "waifu2x-photo-x2": dict(label="Waifu2x 2x - photo model", exe="waifu2x-ncnn-vulkan", scale=2,
                             args=["-n", "1", "-s", "2", "-m", "models-upconv_7_photo"]),
    "waifu2x-cunet-x2": dict(label="Waifu2x 2x - cunet model", exe="waifu2x-ncnn-vulkan", scale=2,
                             args=["-n", "1", "-s", "2", "-m", "models-cunet"]),
    "realesrgan-x4plus": dict(label="Real-ESRGAN x4plus (optional)", exe="realesrgan-ncnn-vulkan", scale=4,
                              args=["-n", "realesrgan-x4plus", "-s", "4"]),
    "none": dict(label="No pre-upscale (plain Lanczos resize)", exe=None, scale=1, args=[]),
}


def find_tool(name):
    if TOOLS.exists():
        for p in TOOLS.rglob(name + EXE):
            return p
    w = shutil.which(name)
    return Path(w) if w else None


class Tools:
    def __init__(self, ffmpeg, ffprobe):
        self.ffmpeg, self.ffprobe = ffmpeg, ffprobe


def get_tools():
    d = APP / "ffmpeg" / "bin"
    ff, fp = d / ("ffmpeg" + EXE), d / ("ffprobe" + EXE)
    if ff.is_file() and fp.is_file():
        return Tools(ff, fp)
    a, b = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if a and b:
        return Tools(Path(a), Path(b))
    raise RuntimeError("FFmpeg not found - run setup.bat")


class Cancelled(Exception):
    pass


class Job:
    def __init__(self, kind):
        self.id, self.kind = uuid.uuid4().hex[:8], kind
        self.state, self.phase, self.done, self.total = "running", "starting", 0, 0
        self.error, self.result, self.cancel, self.proc, self.runner = None, {}, False, None, None
        self.batch = None
        self.log, self.t0 = deque(maxlen=200), time.time()
        self.dir = WORK / self.id
        self.dir.mkdir(parents=True)

    def snapshot(self):
        for _ in range(5):
            try:
                return list(self.log)
            except RuntimeError:  # deque changed while copying
                time.sleep(0.01)
        return []

    def info(self):
        return dict(id=self.id, kind=self.kind, state=self.state, phase=self.phase, done=self.done, total=self.total,
                    error=self.error, result=self.result, log=self.snapshot(), elapsed=int(time.time() - self.t0))

    def run(self, cmd, cwd=None):
        """Run an external tool, keep its log, and honour Cancel."""
        if self.cancel:
            raise Cancelled()
        cmd = [str(c) for c in cmd]
        self.log.append("> " + " ".join('"%s"' % c if " " in c else c for c in cmd))
        self.proc = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                     errors="replace", creationflags=NOWIN)
        for line in self.proc.stdout:
            line = line.strip()
            if line and not re.fullmatch(r"[\d.]+%", line):
                self.log.append(line)
        rc = self.proc.wait()
        if self.cancel:
            raise Cancelled()
        if rc:
            raise RuntimeError("%s exited with code %d (see log)" % (Path(cmd[0]).name, rc))


# ---------------------------------------------------------------- geometry

def plan_geometry(info, target_short, dlss_factor):
    """Centre-crop to the target aspect, then work out the size DLSS (or the encoder) receives."""
    w, h = info["width"], info["height"]
    short = int(target_short)
    long_ = short * 16 // 9
    tw, th = (short, long_) if h > w else (long_, short)
    if w * th > h * tw:
        ch, cw = h, round(h * tw / th)
    else:
        cw, ch = w, round(w * th / tw)
    cw, ch = cw - cw % 2, ch - ch % 2
    cx, cy = (w - cw) // 2, (h - ch) // 2
    if dlss_factor:
        # DLSS input: the target divided by the factor, rounded UP to even numbers. When that is not exact
        # (2K with 1.5x or 3x) DLSS returns a few pixels too many and the extra edge pixels are trimmed.
        mw, mh = math.ceil(tw / dlss_factor - 1e-9), math.ceil(th / dlss_factor - 1e-9)
        mw, mh = mw + mw % 2, mh + mh % 2
        ow, oh = resolve_output_size(mw, mh, dlss_factor)
        if ow < tw or oh < th or ow - tw > 8 or oh - th > 8:
            raise RuntimeError("DLSS %gx cannot reach %dx%d closely enough (it would give %dx%d)" % (dlss_factor, tw, th, ow, oh))
    else:
        mw, mh, ow, oh = tw, th, tw, th
    return dict(tw=tw, th=th, crop=(cx, cy, cw, ch), mid=(mw, mh), out=(ow, oh), vertical=h > w,
                lost=1 - (cw * ch) / (w * h))


def resize(rgba, w, h):
    if rgba.shape[1] == w and rgba.shape[0] == h:
        return rgba
    interp = cv2.INTER_AREA if w * h < rgba.shape[0] * rgba.shape[1] else cv2.INTER_LANCZOS4
    return cv2.resize(rgba, (w, h), interpolation=interp)


def color_args(matrix):
    """RGB frames -> YUV with the SAME matrix the source used, tagged so players do not guess."""
    tag = "bt709" if matrix == "bt709" else "smpte170m"
    return ["-vf", "scale=out_color_matrix=%s:out_range=tv,format=yuv420p" % matrix,
            "-colorspace", tag, "-color_primaries", tag, "-color_trc", tag, "-color_range", "tv"]


def chunk_size(eng, geo):
    cw, ch = geo["crop"][2:]
    out_bytes = cw * ch * eng["scale"] ** 2 * 4
    return max(4, min(48, int(1.2e9 // (out_bytes * 1.3))))


# ---------------------------------------------------------------- decoding

def detect_matrix(path, height):
    try:
        c = av.open(str(path))
        code = int(c.streams.video[0].codec_context.colorspace)
        c.close()
    except Exception:
        code = 2
    if code in (5, 6):
        return "bt601"
    if code == 1:
        return "bt709"
    return "bt709" if height >= 720 else "bt601"


def to_rgba(frame, matrix):
    try:
        return frame.reformat(format="rgba", src_colorspace="ITU709" if matrix == "bt709" else "ITU601").to_ndarray()
    except Exception:
        return frame.to_ndarray(format="rgba")


def source_frames(job, path, info, matrix, start_frame, count):
    container = av.open(str(path))
    try:
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"
        for i, frame in enumerate(container.decode(stream)):
            if i < start_frame:
                continue
            if count and i >= start_frame + count:
                break
            if job.cancel:
                raise Cancelled()
            yield media.rotate_frame(to_rgba(frame, matrix), info["rotation"])
    finally:
        container.close()


def grab_frame(path, t, info, matrix):
    c = av.open(str(path))
    try:
        s = c.streams.video[0]
        if t > 1.0:
            c.seek(int(t / s.time_base), stream=s, backward=True)
        last = None
        for fr in c.decode(s):
            last = fr
            if fr.time is not None and fr.time >= t - 0.001:
                break
        if last is None:
            raise RuntimeError("Could not read a frame at %.2f s" % t)
        return media.rotate_frame(to_rgba(last, matrix), info["rotation"])
    finally:
        c.close()


# ---------------------------------------------------------------- stages

def run_engine(job, eng, frames):
    if not eng["exe"]:
        return frames
    exe = find_tool(eng["exe"])
    if not exe:
        raise RuntimeError("%s not found in the tools folder - run setup.bat" % eng["exe"])
    base = job.dir / "chunk"
    shutil.rmtree(base, ignore_errors=True)
    din, dout = base / "in", base / "out"
    din.mkdir(parents=True)
    dout.mkdir()
    for i, f in enumerate(frames):
        _, buf = cv2.imencode(".png", cv2.cvtColor(f, cv2.COLOR_RGBA2BGR), [cv2.IMWRITE_PNG_COMPRESSION, 1])
        (din / ("%06d.png" % i)).write_bytes(buf.tobytes())
    job.run([exe, "-i", din, "-o", dout, "-f", "png"] + eng["args"], cwd=exe.parent)
    out = []
    for i in range(len(frames)):
        f = dout / ("%06d.png" % i)
        img = cv2.imdecode(np.frombuffer(f.read_bytes(), np.uint8), cv2.IMREAD_COLOR) if f.is_file() else None
        if img is None:
            raise RuntimeError("%s did not produce frame %d (see log)" % (eng["label"], i))
        out.append(cv2.cvtColor(img, cv2.COLOR_BGR2RGBA))
    shutil.rmtree(base, ignore_errors=True)
    return out


def quiet(fn):
    try:
        fn()
    except Exception:
        pass


class DlssRunner:
    """One DLSS 5 worker session fed frame by frame (same call sequence as the upstream selftest)."""

    def __init__(self, s, in_w, in_h, n_frames, expect, target):
        self.layout = dpaths.find_runtime()
        self.options = DlssOptions.create(
            upscaling_mode=s["up"], nr_preset="Default", nr_style=s["style"], dlss_model_preset=s["model"],
            nr_intensity=float(s["intensity"]), local_tone_strength=float(s["tone"]),
            local_structure_strength=float(s["structure"]), skin_structure_strength=float(s["skin"]),
            automatic_mask=bool(s["mask"]), motion_mode=s.get("motion", "auto"),
            scene_change_threshold=float(s.get("thresh", 0.24)), flow_width=int(float(s.get("flow", 640))),
            warmup_frames=int(float(s.get("warm", 0))))
        self.session = DlssSession(self.layout, self.options, input_width=in_w, input_height=in_h, frame_count=n_frames)
        if (self.session.output_width, self.session.output_height) != tuple(expect):
            self.session.abort()
            raise RuntimeError("DLSS would output %dx%d instead of %dx%d" % (
                self.session.output_width, self.session.output_height, *expect))
        self.guide = TemporalGuide(self.session.render_width, self.session.render_height,
                                   flow_width=self.options.flow_width,
                                   scene_change_threshold=self.options.scene_change_threshold,
                                   enabled=self.options.wants_motion(n_frames))
        self.i = 0
        self.target = tuple(target)

    def step(self, rgba):
        r = fit_frame(rgba, self.session.render_width, self.session.render_height)
        g = self.guide.process(r)
        out, _ = self.session.submit(index=self.i, rgba=r, motion=g.motion, reset=g.reset, pts=self.i)
        self.i += 1
        tw, th = self.target
        if out.shape[1] != tw or out.shape[0] != th:  # trim the few extra edge pixels (2K with 1.5x / 3x)
            y, x = (out.shape[0] - th) // 2, (out.shape[1] - tw) // 2
            out = np.ascontiguousarray(out[y:y + th, x:x + tw])
        return out

    def close(self):
        self.session.close()

    def abort(self):
        self.session.abort()

    def verify(self, job, wanted):
        if not wanted:
            return
        try:
            rep = self.session.feature_report()
            job.log.append("DLSS 5 neural rendering verified (feature 18)." +
                           (" Note: 'NR upscaling fell back to native' is normal on current runtimes." if rep["native_fallback"] else ""))
        except RuntimeError as e:
            msg = "WARNING: could not verify DLSS 5 execution: " + str(e).splitlines()[0]
            job.log.append(msg)
            job.result["warning"] = msg


# ---------------------------------------------------------------- frame interpolation (RIFE, runs BEFORE upscaling)

INTERP_FACTORS = (2.0, 2.5)
INTERP_CHUNK = 24          # source intervals per RIFE call (must be even so 2.5x lands on whole frames)
RIFE_MODE = {"mode": None}  # which way of calling rife-ncnn-vulkan produced correctly aligned frames


def write_png(path, rgba, level=1):
    _, buf = cv2.imencode(".png", cv2.cvtColor(rgba, cv2.COLOR_RGBA2BGR), [cv2.IMWRITE_PNG_COMPRESSION, level])
    path.write_bytes(buf.tobytes())


def read_png(path):
    img = cv2.imdecode(np.frombuffer(path.read_bytes(), np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise RuntimeError("Could not read %s" % path.name)
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGBA)


def rife_model(exe):
    names = sorted(d.name for d in exe.parent.iterdir() if d.is_dir() and d.name.startswith("rife"))
    if "rife-v4.6" in names:
        return "rife-v4.6"
    v4 = [n for n in names if n.startswith("rife-v4")]
    if v4:
        return v4[-1]
    raise RuntimeError("No RIFE v4 model folder next to %s (arbitrary-time interpolation needs a v4 model)" % exe.name)


def thumb(rgba):
    return cv2.cvtColor(cv2.resize(rgba, (160, 90), interpolation=cv2.INTER_AREA), cv2.COLOR_RGBA2GRAY).astype(np.int16)


def anchors_match(outs, seq, f):
    """Output frames at whole input positions must reproduce those input frames, otherwise the order is not what we expect."""
    m, worst = len(seq) - 1, 0.0
    for k in sorted({0, (m // 4) // 2 * 2, (m // 2) // 2 * 2, (3 * m // 4) // 2 * 2, m}):
        i = int(round(k * f))
        if i >= len(outs):
            return False, 99.0
        worst = max(worst, float(np.abs(thumb(outs[i]) - thumb(seq[k])).mean()))
    return worst < 3.0, worst


def cut_flags(seq, thresh):
    t = [thumb(x) for x in seq]
    return [float(np.abs(t[k + 1] - t[k]).mean()) / 255.0 > thresh for k in range(len(seq) - 1)]


def rife_pass(job, seq, f, thresh):
    """seq: source frames (an even number of intervals). Returns frames at positions i/f, i = 0 .. (len(seq)-1)*f."""
    exe = find_tool("rife-ncnn-vulkan")
    if not exe:
        raise RuntimeError("RIFE is not installed - run setup.bat")
    job.phase = "Interpolating frames (RIFE)"
    m = len(seq) - 1
    M = int(round(m * f)) + 1
    base = job.dir / "rife"
    shutil.rmtree(base, ignore_errors=True)
    din = base / "in"
    din.mkdir(parents=True)
    for i, fr in enumerate(seq):
        write_png(din / ("%08d.png" % (i + 1)), fr)
    uhd = ["-u"] if seq[0].shape[1] > 2000 else []
    model = rife_model(exe)
    modes = [RIFE_MODE["mode"]] if RIFE_MODE["mode"] else (["n", "default"] if f == 2 else ["n"])
    diag, outs = [], None
    for mode in modes:
        dout = base / ("out_" + mode)
        dout.mkdir()
        job.run([exe, "-i", din, "-o", dout, "-m", model, "-f", "%08d.png"] + uhd + (["-n", M] if mode == "n" else []),
                cwd=exe.parent)
        files = sorted(dout.glob("*.png"))
        if len(files) < M:
            diag.append("%s: %d frames, expected %d" % (mode, len(files), M))
            continue
        cand = [read_png(x) for x in files[:M]]
        ok, worst = anchors_match(cand, seq, f)
        if ok:
            RIFE_MODE["mode"], outs = mode, cand
            break
        diag.append("%s: anchor mismatch %.1f" % (mode, worst))
    if outs is None:
        raise RuntimeError("RIFE's output did not line up with the input frames (%s). Please send me the log." % "; ".join(diag))
    for k in range(0, m + 1):  # keep the untouched originals on the whole-frame positions
        if abs(k * f - round(k * f)) < 1e-9:
            outs[int(round(k * f))] = seq[k]
    for k, cut in enumerate(cut_flags(seq, thresh)):  # no morphing across hard cuts: hold the nearest real frame
        if cut:
            for i in range(int(math.floor(k * f)) + 1, int(math.ceil((k + 1) * f))):
                pos = i / f
                if k + 1e-9 < pos < k + 1 - 1e-9:
                    outs[i] = seq[k] if pos - k < 0.5 else seq[k + 1]
    shutil.rmtree(base, ignore_errors=True)
    return outs


def interp_stream(job, frames, f, thresh):
    """Yield the source frames with RIFE frames in between: f times the frame rate, same duration."""
    it, buf, a, eof = iter(frames), [], 0, False
    while True:
        while len(buf) < INTERP_CHUNK + 1 and not eof:
            nxt = next(it, None)
            if nxt is None:
                eof = True
            else:
                buf.append(nxt)
        if eof:
            need = int(math.floor((a + len(buf)) * f + 1e-9)) - int(round(a * f))
            if need <= 0 or not buf:
                return
            seq = list(buf)
            if len(seq) == 1:
                outs = [seq[0]]
            else:
                while (len(seq) - 1) % 2:
                    seq.append(seq[-1])
                outs = rife_pass(job, seq, f, thresh)
            yield from outs[:need] + [outs[-1]] * max(0, need - len(outs))
            return
        outs = rife_pass(job, buf[:INTERP_CHUNK + 1], f, thresh)
        yield from outs[:-1]
        buf = buf[INTERP_CHUNK:]
        a += INTERP_CHUNK


def prepare(p):
    tools = get_tools()
    path = Path(p["path"])
    if not path.is_file():
        raise RuntimeError("File not found: %s" % path)
    info = media.probe_video(tools, path)
    eng = ENGINES[p["engine"]]
    if eng["exe"] and not find_tool(eng["exe"]):
        raise RuntimeError("%s is not installed - run setup.bat" % eng["label"])
    dlss = p.get("dlss")
    factor = resolve_upscaling(dlss["up"])[0] if dlss else None
    geo = plan_geometry(info, p["target"], factor)
    return tools, path, info, eng, dlss, geo


def save_png(path, rgba):
    _, buf = cv2.imencode(".png", cv2.cvtColor(rgba, cv2.COLOR_RGBA2BGR), [cv2.IMWRITE_PNG_COMPRESSION, 3])
    path.write_bytes(buf.tobytes())


def do_preview(job, p):
    tools, path, info, eng, dlss, geo = prepare(p)
    matrix = detect_matrix(path, info["height"])
    job.phase = "Reading frame"
    cx, cy, cw, ch = geo["crop"]
    frame = grab_frame(path, float(p.get("time") or 0), info, matrix)
    cropped = np.ascontiguousarray(frame[cy:cy + ch, cx:cx + cw])
    tw, th = geo["tw"], geo["th"]
    job.phase = "Pre-upscaling with " + eng["label"]
    mid = resize(run_engine(job, eng, [cropped])[0], *geo["mid"])
    out = mid
    if dlss:
        job.phase = "DLSS 5 neural rendering"
        runner = job.runner = DlssRunner(dlss, *geo["mid"], 1, geo["out"], (tw, th))
        try:
            out = runner.step(mid)
            runner.close()
        except BaseException:
            quiet(runner.abort)
            raise
        runner.verify(job, dlss.get("verify", True))
    save_png(job.dir / "original.png", cropped)
    save_png(job.dir / "ai.png", out)
    job.result.update(original="/work/%s/original.png" % job.id, ai="/work/%s/ai.png" % job.id)
    job.state = "done"


def unique(base, ext):
    f, i = Path("%s.%s" % (base, ext)), 1
    while f.exists():
        f, i = Path("%s_%d.%s" % (base, i, ext)), i + 1
    return f


def do_render(job, p):
    tools, path, info, eng, dlss, geo = prepare(p)
    codec, container, quality = p["codec"], p["container"], p["quality"]
    media.validate_codec_container(codec, container)
    matrix = detect_matrix(path, info["height"])
    fps = info["fps"]
    start = float(p.get("start") or 0)
    start_f = int(round(start * fps))
    want = int(round(float(p.get("duration") or 0) * fps))
    # The DLSS worker is told the exact number of frames up front and exits after that many, so count them exactly.
    total = media.probe_video(tools, path, exact_frames=True)["frames"] if dlss else 0
    total = total or info["frames"] or int(round(info["duration"] * fps))
    n = min(want, total - start_f) if want else total - start_f
    if n <= 0:
        raise RuntimeError("Nothing to render: the start time is at or past the end of the video")
    count = n
    interp = p.get("interp")
    f = 1.0
    if interp:
        f = float(interp["factor"])
        if f not in INTERP_FACTORS:
            raise RuntimeError("The interpolation factor must be 2 or 2.5")
        if not find_tool("rife-ncnn-vulkan"):
            raise RuntimeError("RIFE is not installed - run setup.bat")
    n_out = int(math.floor(n * f + 1e-9))
    job.total = n_out
    cx, cy, cw, ch = geo["crop"]
    tw, th = geo["tw"], geo["th"]
    mw, mh = geo["mid"]
    job.log.append("Source %dx%d -> crop %dx%d (removes %.1f%% of the frame) -> %s%dx%d%s" % (
        info["width"], info["height"], cw, ch, geo["lost"] * 100, "pre-upscale -> " if eng["exe"] else "",
        mw, mh, " -> DLSS5 -> %dx%d" % (tw, th) if dlss else ""))
    if geo["lost"] > 0.08:
        job.log.append("WARNING: this source is not close to 16:9, so a lot of the picture is cropped away.")
    if eng["exe"] and cw * eng["scale"] > mw * 1.1:
        job.log.append("NOTE: %s makes %dx%d but DLSS only needs %dx%d, so it is scaled back down. "
                       "'No pre-upscale' would be faster for a source this large." % (eng["label"], cw * eng["scale"], ch * eng["scale"], mw, mh))
    if interp:
        job.log.append("Frame interpolation (RIFE) x%g: %.3f -> %.3f fps, %d -> %d frames (same duration)" % (f, fps, fps * f, n, n_out))
    outdir = Path(p.get("outdir") or path.parent)
    outdir.mkdir(parents=True, exist_ok=True)
    ext = "mp4" if container == "MP4" else "mkv"
    final = unique(outdir / ("%s_%dp%s%s" % (path.stem, geo["th"] if not geo["vertical"] else geo["tw"], "_dlss5" if dlss else "", "_x%g" % f if interp else "")), ext)
    tmp = job.dir / "video_only.mkv"
    rate = info["rate"] * Fraction(f).limit_denominator(10)
    cropped_iter = (np.ascontiguousarray(fr[cy:cy + ch, cx:cx + cw])
                    for fr in source_frames(job, path, info, matrix, start_f, count))
    stream = interp_stream(job, cropped_iter, f, float(dlss.get("thresh", 0.24)) if dlss else 0.24) if interp else cropped_iter
    n_chunk = chunk_size(eng, geo)
    runner = enc = None
    idx = 0
    try:
        if dlss:
            job.phase = "Starting the DLSS 5 worker"
            runner = job.runner = DlssRunner(dlss, mw, mh, n_out, geo["out"], (tw, th))
        enc = media.RawFrameEncoder(tools, tmp, codec=codec, quality=quality, width=tw, height=th, rate=rate,
                                    time_base=Fraction(1) / rate, extra=color_args(matrix))
        while True:
            chunk = list(islice(stream, n_chunk))
            if not chunk:
                break
            job.phase = "Pre-upscaling (%s)" % eng["label"] if eng["exe"] else "Processing"
            ups = run_engine(job, eng, chunk)
            job.phase = "DLSS 5 + encoding" if dlss else "Encoding"
            for up in ups:
                if job.cancel:
                    raise Cancelled()
                frame = last = resize(up, mw, mh)
                enc.write(runner.step(frame) if runner else frame, idx)
                idx += 1
                job.done = idx
        if idx == 0:
            raise RuntimeError("No frames could be decoded from the selected range")
        if runner and idx < n_out:  # decoder returned fewer frames than counted: repeat the last one so the worker ends cleanly
            job.log.append("Decoded %d of %d expected frames; repeating the last frame to finish cleanly." % (idx, n_out))
            while idx < n_out:
                enc.write(runner.step(last), idx)
                idx += 1
                job.done = idx
        if runner:
            runner.close()
            runner.verify(job, dlss.get("verify", True))
        job.phase = "Finishing the video file"
        enc.close()
    except BaseException:
        if runner:
            quiet(runner.abort)
        if enc:
            quiet(enc.abort)
        raise
    job.phase = "Adding the original audio"
    media.mux(tools, tmp, path, final, container, copy_audio=True, source_start=start)
    job.result["file"] = str(final)
    job.state = "done"


def pipeline(job, p):
    try:
        (do_preview if job.kind == "preview" else do_render)(job, p)
    except Cancelled:
        job.state = "cancelled"
    except Exception as e:
        if job.cancel:
            job.state = "cancelled"
        else:
            job.state, job.error = "error", str(e)
            job.log.append(traceback.format_exc()[-1500:])
    finally:
        shutil.rmtree(job.dir / "chunk", ignore_errors=True)
        if job.kind == "render":
            shutil.rmtree(job.dir, ignore_errors=True)


JOB, LOCK = None, threading.Lock()
QUEUE = dict(running=False, cancel=False, batch=None, items=[])
DATA = APP / "data"
FILE_LOCK = threading.Lock()


# ---------------------------------------------------------------- small JSON store (profiles, history)

def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def load_json(name, default):
    try:
        return json.loads((DATA / name).read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(name, obj):
    DATA.mkdir(exist_ok=True)
    f = DATA / name
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=1), encoding="utf-8")
    tmp.replace(f)


def clean_name(n):
    n = re.sub(r"\s+", " ", str(n or "")).strip()[:60]
    if not n:
        raise ValueError("Please give the profile a name")
    return n


def unique_name(name, existing):
    if name not in existing:
        return name
    i = 2
    while "%s (%d)" % (name, i) in existing:
        i += 1
    return "%s (%d)" % (name, i)


def clean_settings(s):
    if not isinstance(s, dict):
        raise ValueError("Invalid settings")
    return {k: v for k, v in list(s.items())[:60] if isinstance(k, str) and isinstance(v, (str, int, float, bool))}


def profiles_action(body):
    """Save / rename / duplicate / delete / import profiles. Returns (all profiles, name to select)."""
    with FILE_LOCK:
        prof = load_json("profiles.json", {})
        act, created = body.get("action"), None
        if act == "save":
            created = clean_name(body.get("name"))
            prof[created] = dict(settings=clean_settings(body.get("settings")), updated=now_iso())
        elif act == "rename":
            old, created = body.get("name"), clean_name(body.get("new_name"))
            if old not in prof:
                raise ValueError("Profile not found")
            if created != old and created in prof:
                raise ValueError("A profile with that name already exists")
            prof[created] = prof.pop(old)
        elif act == "duplicate":
            old = body.get("name")
            if old not in prof:
                raise ValueError("Profile not found")
            created = unique_name(old + " copy", prof)
            prof[created] = dict(settings=dict(prof[old]["settings"]), updated=now_iso())
        elif act == "delete":
            prof.pop(body.get("name"), None)
        elif act == "import":
            data = body.get("data")
            items = {}
            if isinstance(data, dict) and isinstance(data.get("profiles"), dict):
                items = {k: v.get("settings") for k, v in data["profiles"].items() if isinstance(v, dict)}
            elif isinstance(data, dict) and "settings" in data:
                items = {data.get("name") or "Imported profile": data["settings"]}
            if not items:
                raise ValueError("This file does not look like an exported profile")
            for k, v in items.items():
                created = unique_name(clean_name(k), prof)
                prof[created] = dict(settings=clean_settings(v), updated=now_iso())
        else:
            raise ValueError("Unknown action")
        save_json("profiles.json", prof)
        return prof, created


def history_add(entry):
    with FILE_LOCK:
        h = load_json("history.json", [])
        h.append(entry)
        save_json("history.json", h[-3000:])


def history_delete(body):
    with FILE_LOCK:
        h = load_json("history.json", [])
        n0, mode = len(h), body.get("mode")
        if mode == "ids":
            ids = set(body.get("ids") or [])
            h = [e for e in h if e.get("id") not in ids]
        elif mode == "batch":
            b = {x for x in (body.get("batches") or []) if x}
            h = [e for e in h if e.get("batch") not in b]
        elif mode == "date":
            d = str(body.get("date") or "")
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", d):
                raise ValueError("Pick a date first")
            h = [e for e in h if e.get("day") != d]
        elif mode == "all":
            h = []
        else:
            raise ValueError("Unknown delete mode")
        save_json("history.json", h)
        return n0 - len(h)


# ---------------------------------------------------------------- jobs, history records, batch queue

def gpu_info():
    exe = shutil.which("nvidia-smi")
    if not exe:
        return None
    r = subprocess.run([exe, "--query-gpu=name,memory.used,memory.total,utilization.gpu", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, creationflags=NOWIN)
    try:
        n, u, t, g = [x.strip() for x in r.stdout.strip().splitlines()[0].split(",")]
        return dict(name=n, used=int(u), total=int(t), util=int(g))
    except Exception:
        return None


class VramSampler:
    """Samples GPU memory use while a job runs (whole-GPU figure from nvidia-smi, so it includes other programs)."""

    def __init__(self):
        self.peak, self.start, self.total, self.name = 0, None, None, None
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop.is_set():
            g = gpu_info()
            if g:
                self.name, self.total = g["name"], g["total"]
                if self.start is None:
                    self.start = g["used"]
                self.peak = max(self.peak, g["used"])
            self._stop.wait(1.5)

    def begin(self):
        self._t.start()
        return self

    def end(self):
        self._stop.set()
        self._t.join(timeout=4)


def new_job(p, batch=None):
    global JOB
    with LOCK:
        if JOB and JOB.state == "running":
            raise RuntimeError("A job is already running")
        if JOB:
            shutil.rmtree(JOB.dir, ignore_errors=True)
        JOB = Job(p["kind"])
        JOB.batch = batch
        return JOB


def record(job, p, vr):
    frames = job.done if job.kind == "render" else 1
    elapsed = max(1, int(time.time() - job.t0))
    settings = {k: v for k, v in p.items() if k != "path"}
    settings["engine_label"] = ENGINES.get(p.get("engine"), {}).get("label", p.get("engine"))
    history_add(dict(
        id=job.id, ts=now_iso(), day=datetime.now().strftime("%Y-%m-%d"), kind=job.kind, status=job.state,
        batch=job.batch, source=Path(p["path"]).name, path=p["path"], elapsed=elapsed, frames=frames,
        fps=round(frames / elapsed, 2) if job.kind == "render" and frames else None,
        gpu=vr.name, vram_start=vr.start, vram_peak=vr.peak or None, vram_total=vr.total,
        settings=settings, output=job.result.get("file"), error=job.error))


def execute(job, p):
    vr = VramSampler().begin()
    try:
        pipeline(job, p)
    finally:
        vr.end()
        try:
            record(job, p, vr)
        except Exception:
            pass


def start_job(p):
    if QUEUE["running"]:
        raise RuntimeError("The batch queue is running")
    job = new_job(p)
    threading.Thread(target=execute, args=(job, p), daemon=True).start()
    return job


def run_queue(p):
    try:
        for it in QUEUE["items"]:
            if QUEUE["cancel"]:
                it["status"] = "cancelled"
                continue
            it["status"] = "running"
            q = dict(p, path=it["path"], kind="render")
            if not p.get("apply_range"):
                q["start"] = q["duration"] = ""
            try:
                job = new_job(q, QUEUE["batch"])
                execute(job, q)
                it["status"], it["file"], it["error"] = job.state, job.result.get("file"), job.error
            except Exception as e:
                it["status"], it["error"] = "error", str(e)
    finally:
        QUEUE["running"] = False


def start_batch(p, paths):
    paths = [str(x).strip().strip('"') for x in paths if str(x).strip()]
    if not paths:
        raise RuntimeError("Add at least one video path to the queue")
    with LOCK:
        if QUEUE["running"] or (JOB and JOB.state == "running"):
            raise RuntimeError("Something is already running")
        QUEUE.update(running=True, cancel=False, batch="B-" + datetime.now().strftime("%m%d-%H%M%S"),
                     items=[dict(path=x, status="waiting", file=None, error=None) for x in paths])
    threading.Thread(target=run_queue, args=(p,), daemon=True).start()


def queue_info():
    return dict(running=QUEUE["running"], batch=QUEUE["batch"], items=[dict(i) for i in QUEUE["items"]])


# ---------------------------------------------------------------- video compare: serving files to the browser

VIDEO_TYPES = {".mp4": "video/mp4", ".m4v": "video/mp4", ".mov": "video/quicktime", ".mkv": "video/x-matroska",
               ".webm": "video/webm"}
MEDIA = {}


def media_open(path):
    p = Path(path)
    if not p.is_file():
        raise RuntimeError("File not found: %s" % p)
    if p.suffix.lower() not in VIDEO_TYPES:
        raise RuntimeError("Unsupported file type (use mp4, m4v, mov, mkv or webm)")
    i = media.probe_video(get_tools(), p)
    tok = uuid.uuid4().hex[:10]
    MEDIA[tok] = dict(path=p, proxy=None, state="none", error=None)
    return dict(token=tok, name=p.name, width=i["width"], height=i["height"], fps=i["fps"], duration=i["duration"],
                codec=i["codec"])


def _proxy_worker(m, tok, height):
    out = WORK / "proxy" / ("%s.mp4" % tok)
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        ff = get_tools().ffmpeg
        vf = ["-vf", "scale=-2:%d" % height] if height else []
        r = None
        for enc in (["-c:v", "h264_nvenc", "-preset", "p5", "-cq", "19"], ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18"]):
            cmd = [str(ff), "-y", "-i", str(m["path"]), "-map", "0:v:0", "-map", "0:a:0?"] + vf + enc + [
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(out)]
            r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", creationflags=NOWIN)
            if r.returncode == 0:
                m.update(proxy=out, state="done")
                return
        m.update(state="error", error=(r.stderr if r else "")[-300:])
    except Exception as e:
        m.update(state="error", error=str(e))


def media_proxy(tok, height):
    m = MEDIA.get(tok)
    if not m:
        raise RuntimeError("Unknown video")
    if m["state"] != "running":
        m.update(state="running", error=None)
        threading.Thread(target=_proxy_worker, args=(m, tok, int(height or 0)), daemon=True).start()


# ---------------------------------------------------------------- server

def status():
    try:
        rt = dict(ok=True, path=str(dpaths.find_runtime().root))
    except Exception as e:
        rt = dict(ok=False, msg=str(e).splitlines()[0])
    try:
        get_tools()
        ff = True
    except Exception:
        ff = False
    return dict(gpu=gpu_info(), runtime=rt, ffmpeg=ff, rife=bool(find_tool("rife-ncnn-vulkan")),
                engines={k: dict(label=v["label"], ok=(not v["exe"]) or bool(find_tool(v["exe"]))) for k, v in ENGINES.items()})


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, body, ctype="application/json", code=200):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def serve_media(self, tok, want_proxy):
        m = MEDIA.get(tok)
        if not m:
            return self.send({}, code=404)
        f = m["proxy"] if (want_proxy and m["proxy"]) else m["path"]
        ctype = "video/mp4" if f is m["proxy"] else VIDEO_TYPES.get(f.suffix.lower(), "application/octet-stream")
        size = f.stat().st_size
        start, end, code = 0, size - 1, 200
        rng = re.fullmatch(r"bytes=(\d*)-(\d*)", (self.headers.get("Range") or "").strip())
        if rng:
            a, b = rng.groups()
            if a == "" and b:
                start = max(0, size - int(b))
            else:
                start = int(a or 0)
                end = min(int(b), size - 1) if b else size - 1
            code = 206
        if start > end or start >= size:
            self.send_response(416)
            self.send_header("Content-Range", "bytes */%d" % size)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if code == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.end_headers()
        try:
            with open(f, "rb") as fh:
                fh.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = fh.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def do_GET(self):
        try:
            self._get()
        except Exception as e:
            try:
                self.send(dict(error=str(e)), code=500)
            except Exception:
                pass

    def _get(self):
        u = urlparse(self.path)
        path, qs = u.path, parse_qs(u.query)
        if path == "/":
            self.send((APP / "ui.html").read_text(encoding="utf-8"), "text/html; charset=utf-8")
        elif path == "/api/status":
            self.send(status())
        elif path == "/api/job":
            self.send(dict(JOB.info() if JOB else {}, queue=queue_info()))
        elif path == "/api/profiles":
            self.send(dict(profiles=load_json("profiles.json", {})))
        elif path == "/api/history":
            self.send(dict(history=load_json("history.json", [])))
        elif path == "/api/media/status":
            m = MEDIA.get((qs.get("token") or [""])[0])
            self.send(dict(state=m["state"], error=m["error"]) if m else dict(error="unknown video"))
        elif path.startswith("/media/"):
            self.serve_media(path[7:], "proxy" in qs)
        elif path.startswith("/work/"):
            f = (WORK / unquote(path[6:])).resolve()
            if WORK.resolve() in f.parents and f.is_file():
                self.send(f.read_bytes(), "image/png")
            else:
                self.send({}, code=404)
        else:
            self.send({}, code=404)

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        path = self.path.split("?")[0]
        try:
            if path == "/api/probe":
                i = media.probe_video(get_tools(), Path(body["path"]))
                self.send({k: i[k] for k in ("width", "height", "fps", "duration", "frames", "codec", "hdr", "rotation")})
            elif path == "/api/start":
                self.send(start_job(body).info())
            elif path == "/api/queue/start":
                start_batch(body, body.pop("paths", []))
                self.send(queue_info())
            elif path == "/api/cancel":
                if QUEUE["running"]:
                    QUEUE["cancel"] = True
                if JOB and JOB.state == "running":
                    JOB.cancel = True
                    if JOB.proc and JOB.proc.poll() is None:
                        JOB.proc.terminate()
                    if JOB.runner:
                        quiet(JOB.runner.abort)
                self.send({})
            elif path == "/api/profiles":
                prof, created = profiles_action(body)
                self.send(dict(profiles=prof, created=created))
            elif path == "/api/history/delete":
                self.send(dict(deleted=history_delete(body)))
            elif path == "/api/media/open":
                self.send(media_open(body["path"]))
            elif path == "/api/media/proxy":
                media_proxy(body["token"], body.get("height"))
                self.send({})
            else:
                self.send({}, code=404)
        except Exception as e:
            self.send(dict(error=str(e)), code=400)


def main():
    shutil.rmtree(WORK, ignore_errors=True)
    WORK.mkdir(exist_ok=True)
    DATA.mkdir(exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = "http://127.0.0.1:%d" % PORT
    print("Upscaler running at %s  (close this window to stop)" % url)
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
