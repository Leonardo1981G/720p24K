@echo off
rem Creates Local-Video-Upscaler-share.zip (one level up) containing ONLY the app files,
rem never python\, tools\, runtime\, ffmpeg\, data\ or work\ (setup.bat recreates those on the other PC).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Recurse -Directory -Filter __pycache__ | Remove-Item -Recurse -Force; Compress-Archive -Force -Path app.py,ui.html,dlss5,setup.bat,setup.ps1,run.bat,README.txt,THIRD_PARTY_NOTICES.txt,LICENSE,make-share-zip.bat -DestinationPath '..\Local-Video-Upscaler-share.zip'"
echo.
echo Created ..\Local-Video-Upscaler-share.zip
pause
