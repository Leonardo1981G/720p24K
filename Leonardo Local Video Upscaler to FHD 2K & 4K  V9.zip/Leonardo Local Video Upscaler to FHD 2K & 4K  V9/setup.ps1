# One-time setup. Everything is installed INSIDE this folder; nothing touches PATH, the registry or other Python installs.
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$App = $PSScriptRoot
Set-Location $App
$Tmp = Join-Path $App "setup_temp"
New-Item -ItemType Directory -Force $Tmp | Out-Null

function Say($m)  { Write-Host $m -ForegroundColor Cyan }
function Warn($m) { Write-Host $m -ForegroundColor Yellow }
function Download($url, $dest) { Write-Host "  downloading $url"; Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing }
function Github-Asset($repo, $pattern, $tag = "") {
    $h = @{ "User-Agent" = "upscaler-setup" }
    if ($tag) { $rels = @(Invoke-RestMethod "https://api.github.com/repos/$repo/releases/tags/$tag" -Headers $h) }
    else { $rels = @(Invoke-RestMethod "https://api.github.com/repos/$repo/releases?per_page=15" -Headers $h) }
    foreach ($r in $rels) {
        $a = $r.assets | Where-Object { $_.name -match $pattern } | Select-Object -First 1
        if ($a) { return $a.browser_download_url }
    }
    throw "No matching download found in $repo"
}
function Ask($q, $default) { $r = Read-Host "$q [$default]"; if ([string]::IsNullOrWhiteSpace($r)) { return $default } else { return $r.Trim().Trim('"') } }

# ---------------------------------------------------------------- 1. local Python
$py = Join-Path $App "python\python.exe"
if (-not (Test-Path $py)) {
    Say "[1/5] Installing a private Python 3.12 into .\python (your other Python installs are not touched)"
    $zip = Join-Path $Tmp "python-embed.zip"
    Download "https://www.python.org/ftp/python/3.12.8/python-3.12.8-embed-amd64.zip" $zip
    Expand-Archive $zip -DestinationPath (Join-Path $App "python") -Force
    $pth = Get-ChildItem (Join-Path $App "python") -Filter "python3*._pth" | Select-Object -First 1
    Set-Content -Path $pth.FullName -Value @("python312.zip", ".", "..", "Lib\site-packages", "import site") -Encoding ASCII
    New-Item -ItemType Directory -Force (Join-Path $App "python\Lib\site-packages") | Out-Null
    Download "https://bootstrap.pypa.io/get-pip.py" (Join-Path $App "python\get-pip.py")
    & $py (Join-Path $App "python\get-pip.py") --no-warn-script-location
    if ($LASTEXITCODE -ne 0) { throw "pip installation failed" }
} else { Say "[1/5] Private Python already present" }
Say "      Installing numpy, av (PyAV) and OpenCV into it"
& $py -m pip install --no-warn-script-location --disable-pip-version-check numpy av "opencv-python>=4.10,<5"
if ($LASTEXITCODE -ne 0) { throw "Installing the Python packages failed" }

# ---------------------------------------------------------------- 2. Waifu2x
Say "[2/5] Waifu2x (ncnn / Vulkan)"
if (Get-ChildItem (Join-Path $App "tools") -Recurse -Filter "waifu2x-ncnn-vulkan.exe" -ErrorAction SilentlyContinue) { Write-Host "  already present" }
else {
    $url = Github-Asset "nihui/waifu2x-ncnn-vulkan" "windows.*\.zip$"
    $zip = Join-Path $Tmp "waifu2x.zip"
    Download $url $zip
    Expand-Archive $zip -DestinationPath (Join-Path $App "tools\waifu2x") -Force
}
$yn = Ask "Also install Real-ESRGAN (optional, 4x model)? y/n" "n"
if ($yn -eq "y" -and -not (Get-ChildItem (Join-Path $App "tools") -Recurse -Filter "realesrgan-ncnn-vulkan.exe" -ErrorAction SilentlyContinue)) {
    try {
        $url = Github-Asset "xinntao/Real-ESRGAN" "ncnn-vulkan.*windows.*\.zip$" "v0.2.5.0"
        $zip = Join-Path $Tmp "realesrgan.zip"
        Download $url $zip
        Expand-Archive $zip -DestinationPath (Join-Path $App "tools\realesrgan") -Force
    } catch {
        Warn "  Real-ESRGAN could not be installed ($($_.Exception.Message)). It is optional - continuing without it."
    }
}

$yn = Ask "Also install RIFE (optional frame interpolation, about 40 MB)? y/n" "y"
if ($yn -eq "y" -and -not (Get-ChildItem (Join-Path $App "tools") -Recurse -Filter "rife-ncnn-vulkan.exe" -ErrorAction SilentlyContinue)) {
    try {
        $url = Github-Asset "nihui/rife-ncnn-vulkan" "windows.*\.zip$"
        $zip = Join-Path $Tmp "rife.zip"
        Download $url $zip
        Expand-Archive $zip -DestinationPath (Join-Path $App "tools\rife") -Force
    } catch {
        Warn "  RIFE could not be installed ($($_.Exception.Message)). It is optional - continuing without it."
    }
}

# ---------------------------------------------------------------- 3. DLSS 5 runtime + FFmpeg
$Required = @("nvngx.dll", "dxgi.dll", "renodx-dlss5.addon64", "nvngx_dlss.dll", "nvngx_dlssnr.dll")
function Runtime-Ok($dir) { foreach ($f in $Required) { if (-not (Test-Path (Join-Path $dir $f))) { return $false } }; return $true }
$rtDir = Join-Path $App "runtime"
$ffDir = Join-Path $App "ffmpeg\bin"
$haveFfmpeg = (Test-Path (Join-Path $ffDir "ffmpeg.exe")) -and (Test-Path (Join-Path $ffDir "ffprobe.exe"))

if (Runtime-Ok $rtDir) { Say "[3/5] DLSS 5 runtime already present" }
else {
    Say "[3/5] DLSS 5 runtime"
    Write-Host "  [1] Copy from an existing ComfyUI + ComfyUI-DLSS5-Enhancer install (recommended; the safe choice for RTX 30-series cards)"
    Write-Host "  [2] Download it from the upstream project (about 470 MB)"
    $presetRoot = ""
    while ($true) {
        $choice = Ask "Choose 1 or 2" "1"
        if ($choice -eq "1" -or $choice -eq "2") { break }
        if (Test-Path $choice) { $presetRoot = $choice; $choice = "1"; break }   # a folder path was typed here: use it
        Warn "  Please type 1 or 2."
    }
    if ($choice -eq "1") {
        # look for an existing ComfyUI install that has the DLSS5 node pack, in the usual places
        $found = @()
        foreach ($b in @("$env:USERPROFILE\Documents", "$env:USERPROFILE\Desktop", "$env:USERPROFILE\Downloads", "$env:USERPROFILE", "C:\", "D:\")) {
            if (-not (Test-Path $b)) { continue }
            foreach ($d in (Get-ChildItem $b -Directory -Filter "ComfyUI*" -ErrorAction SilentlyContinue)) {
                foreach ($c in @($d.FullName, (Join-Path $d.FullName "ComfyUI"))) {
                    if (Test-Path (Join-Path $c "custom_nodes\ComfyUI-DLSS5-Enhancer")) { $found += $c }
                }
            }
        }
        $default = ""
        if ($found.Count -gt 0) { $default = $found[0]; Write-Host "  Found an install with the DLSS5 node pack: $default" }
        else { Write-Host "  No ComfyUI install with ComfyUI-DLSS5-Enhancer was found automatically." }
        $root = if ($presetRoot) { $presetRoot } else { Ask "Path to your ComfyUI folder (the one containing custom_nodes)" $default }
        $node = $null
        foreach ($c in @("$root\custom_nodes\ComfyUI-DLSS5-Enhancer", "$root\ComfyUI\custom_nodes\ComfyUI-DLSS5-Enhancer")) { if (Test-Path $c) { $node = $c; break } }
        if (-not $node) { throw "Could not find custom_nodes\ComfyUI-DLSS5-Enhancer under $root" }
        $lic = Get-ChildItem $node -Filter "LICENSE*" -File -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($lic) { Copy-Item $lic.FullName (Join-Path $App "dlss5\LICENSE-upstream.txt") -Force; Write-Host "  copied the upstream licence file into dlss5" }
        $src = $null
        $cfg = Join-Path $node "config.json"
        if (Test-Path $cfg) { try { $j = Get-Content $cfg -Raw | ConvertFrom-Json; if ($j.runtime_dir -and (Runtime-Ok $j.runtime_dir)) { $src = $j.runtime_dir } } catch {} }
        if (-not $src -and (Runtime-Ok (Join-Path $node "runtime"))) { $src = Join-Path $node "runtime" }
        if (-not $src) { throw "No complete runtime folder found in $node (needs: $($Required -join ', '))" }
        Write-Host "  copying runtime from $src"
        New-Item -ItemType Directory -Force $rtDir | Out-Null
        Copy-Item (Join-Path $src "*") -Destination $rtDir -Recurse -Force -Exclude "*.log"
        if (-not $haveFfmpeg) {
            $ffSrc = $null
            foreach ($c in @((Join-Path $node "ffmpeg\bin"), (Join-Path (Split-Path $src -Parent) "ffmpeg\bin"))) { if (Test-Path (Join-Path $c "ffmpeg.exe")) { $ffSrc = $c; break } }
            if ($ffSrc) { New-Item -ItemType Directory -Force $ffDir | Out-Null; Copy-Item (Join-Path $ffSrc "*") -Destination $ffDir -Force; $haveFfmpeg = $true; Write-Host "  copied FFmpeg from $ffSrc" }
        }
    } else {
        Warn "  The runtime is made of third-party NVIDIA, ReShade and RenoDX components published by the"
        Warn "  'Merserk/dlss5-visual-enhancer' project. It is downloaded from there and used under its own licence terms."
        Warn "  Windows Defender or other antivirus software may flag nvngx.dll (a worker program); that is expected."
        if ((Read-Host "  Type YES to continue") -ne "YES") { throw "Cancelled" }
        $zip = Join-Path $Tmp "runtime.zip"
        try { $url = Github-Asset "Merserk/dlss5-visual-enhancer" "\.zip$" }
        catch { throw "Could not find the runtime download automatically ($($_.Exception.Message)). Use option 1 (copy from ComfyUI) instead." }
        Download $url $zip
        $ex = Join-Path $Tmp "runtime_x"
        Remove-Item $ex -Recurse -Force -ErrorAction SilentlyContinue
        Expand-Archive $zip -DestinationPath $ex -Force
        $w = Get-ChildItem $ex -Recurse -Filter "nvngx.dll" | Select-Object -First 1
        if (-not $w) { throw "The download did not contain the expected runtime files" }
        New-Item -ItemType Directory -Force $rtDir | Out-Null
        Copy-Item (Join-Path $w.DirectoryName "*") -Destination $rtDir -Recurse -Force
        $f = Get-ChildItem $ex -Recurse -Filter "ffmpeg.exe" | Select-Object -First 1
        if ($f -and -not $haveFfmpeg) { New-Item -ItemType Directory -Force $ffDir | Out-Null; Copy-Item (Join-Path $f.DirectoryName "*") -Destination $ffDir -Force; $haveFfmpeg = $true }
        # RTX 30-series needs one exact, tested pair of files (see dlss5\diagnostics.py)
        $gpu = ""
        try { $gpu = (& nvidia-smi --query-gpu=name --format=csv,noheader) | Select-Object -First 1 } catch {}
        if ($gpu -match "RTX 30") {
            $a = (Get-FileHash (Join-Path $rtDir "renodx-dlss5.addon64") -Algorithm SHA256).Hash
            $n = (Get-FileHash (Join-Path $rtDir "nvngx_dlssnr.dll") -Algorithm SHA256).Hash
            if ($a -ne "D5ADF82EB44B065F4C590AC91FE824BAB07AFEA0EB9F994BDE936710C8593952" -or $n -ne "6EB209E764F39872625DEBD6ABAF45E2BB6322F6F270F781F70C059AE30B3927") {
                Warn "  WARNING: you have an RTX 30-series card ($gpu) and this download is NOT the tested pair of files that"
                Warn "  generation needs, so DLSS 5 will probably refuse to run. Use option 1 with a working ComfyUI install,"
                Warn "  or ask for help matching the exact files."
            }
        }
    }
    if (-not (Runtime-Ok $rtDir)) { throw "The runtime folder is incomplete after setup" }
}

if (-not $haveFfmpeg) {
    Say "      FFmpeg (separate download)"
    $zip = Join-Path $Tmp "ffmpeg.zip"
    Download "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip" $zip
    $ex = Join-Path $Tmp "ffmpeg_x"
    Remove-Item $ex -Recurse -Force -ErrorAction SilentlyContinue
    Expand-Archive $zip -DestinationPath $ex -Force
    $f = Get-ChildItem $ex -Recurse -Filter "ffmpeg.exe" | Select-Object -First 1
    New-Item -ItemType Directory -Force $ffDir | Out-Null
    Copy-Item (Join-Path $f.DirectoryName "*.exe") -Destination $ffDir -Force
}

# ---------------------------------------------------------------- upstream licence (MIT) for the dlss5 folder
$licDst = Join-Path $App "dlss5\LICENSE-upstream.txt"
if (-not (Test-Path $licDst)) {
    try {
        $r = Invoke-RestMethod "https://api.github.com/repos/Blueforcer/ComfyUI-DLSS5-Enhancer/license" -Headers @{ "User-Agent" = "upscaler-setup" }
        $text = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(($r.content -replace "\s", "")))
        Set-Content -Path $licDst -Value $text -Encoding UTF8
        Write-Host "  saved the upstream licence to dlss5\LICENSE-upstream.txt"
    } catch {
        Warn "  Could not fetch the upstream licence automatically. Copy the file LICENSE from the ComfyUI-DLSS5-Enhancer folder to dlss5\LICENSE-upstream.txt"
    }
}

# ---------------------------------------------------------------- 4. tidy + self-test
Remove-Item $Tmp -Recurse -Force -ErrorAction SilentlyContinue
Say "[4/5] Self-test of the DLSS 5 worker (sends 3 synthetic frames through it)"
if ((Ask "Run it now? y/n" "y") -eq "y") {
    & $py -m dlss5.selftest --frames 3 --mode "1.5x (Quality)" --width 640 --height 360
    if ($LASTEXITCODE -ne 0) { Warn "  The self-test reported a problem - copy the text above and send it to me." } else { Say "  Self-test passed." }
}
Say "[5/5] Done. Start the app with run.bat"
