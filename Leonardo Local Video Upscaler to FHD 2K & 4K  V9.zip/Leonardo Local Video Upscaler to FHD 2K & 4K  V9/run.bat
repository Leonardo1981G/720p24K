@echo off
cd /d "%~dp0"
if not exist python\python.exe (
  echo Please run setup.bat first.
  pause
  exit /b 1
)
python\python.exe app.py
pause
