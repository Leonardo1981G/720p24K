"""Torch-free subset of the upstream imaging helpers.

The upstream module also converts ComfyUI IMAGE tensors and therefore imports torch.
This standalone app has no ComfyUI, so only the pieces the worker client needs remain
(`cv2`, `require_cv2`, `fit_frame`), copied unchanged from upstream.
"""

from __future__ import annotations

import numpy as np

try:
    import cv2
except ImportError:  # reported when a feature runs, not at import time
    cv2 = None


def require_cv2() -> None:
    if cv2 is None:
        raise RuntimeError(
            "OpenCV is required for frame scaling and motion estimation. "
            "Run setup.bat again to install it."
        )


def fit_frame(rgba: np.ndarray, width: int, height: int) -> np.ndarray:
    """Letterbox an RGBA frame into ``width`` x ``height`` without distortion."""
    require_cv2()
    source_height, source_width = rgba.shape[:2]
    if (source_width, source_height) == (width, height):
        return np.ascontiguousarray(rgba, dtype=np.uint8)

    scale = min(width / source_width, height / source_height)
    fit_width = max(1, min(width, int(round(source_width * scale))))
    fit_height = max(1, min(height, int(round(source_height * scale))))
    interpolation = cv2.INTER_AREA if scale < 1.0 else cv2.INTER_LANCZOS4
    resized = cv2.resize(rgba, (fit_width, fit_height), interpolation=interpolation)

    canvas = np.zeros((height, width, 4), dtype=np.uint8)
    left = (width - fit_width) // 2
    top = (height - fit_height) // 2
    canvas[top : top + fit_height, left : left + fit_width] = resized
    return canvas
