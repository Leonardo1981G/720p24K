"""Vendored client for the DLSS 5 native worker (see NOTICE.txt)."""
